import React from 'react'
import { BrowserRouter as Router, Routes, Route} from 'react-router-dom';
import Home from './Home'
import Details from './Details'
export default function App() {
    return (
        <div>
            <Router>
                <Routes>
                    <Route path="/" exact element={<Home/>} />
                    <Route path="/Details/:id" exact element={<Details/>} />
                </Routes>
            </Router>
        </div>
    )
}