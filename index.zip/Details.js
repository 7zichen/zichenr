import { useEffect, useState } from "react"
import { useParams } from "react-router-dom";
import './css/Details.css'
import changeTime from "./Tool/TimeTool";
const axios = require('axios')
export default function Detail() {
    let params=useParams()
    console.log(params.id);
    let [data, setData] = useState([]);
    useEffect(() => {
        //挂载后 获得服务器的数据
        axios.get("/topic/"+params.id)
            .then(resp => {
                console.log(resp.data.data.content);
                data = resp.data.data
                setData(data)
            })
    }, []);
    return (
        <div id="item">
            <h1>{data.title}</h1>
            <ul>
                <li>发布于:{changeTime(data.last_reply_at)}</li>
                {/* <li>作者：{data.author.loginname}</li> */}
                <li>{data.visit_count}次浏览</li>
                <li>来自:{data.tab}</li>
            </ul>
            <div dangerouslySetInnerHTML={{__html:data.content}}></div>
        </div>
    )
}

