import { useEffect, useState } from "react";
import { Table, Tabs } from 'antd';
import { Link} from "react-router-dom"
import './css/home.css'
import Detail from "./Details";
import changeTime from "./Tool/TimeTool";
const axios = require('axios')
const { TabPane } = Tabs;
export default function Home() {
    let [data, setData] = useState([]);
    useEffect(() => {
        //挂载后 获得服务器的数据
        axios.get('topics')
            .then(resp => {
                console.log(resp.data.data);
                data = resp.data.data
                data.forEach(item => { 
                    item.visit_count = `${item.reply_count} \/ ${item.visit_count}`
                    if (item.top) {
                        item.t = `置顶`
                    } else {
                        if (item.tab == "share") {
                            item.t = `分享`
                        } else {
                            item.t = `问答`
                        }
                    }
                });
                setData(data)
            })
    }, []);
    let columns = [
        {
            dataIndex: 'author',
            tit: 'anthor',
            render: img => <img src={img.avatar_url} title={img.loginname} />
        },
        {
            dataIndex: 'visit_count',
            tit: 'visit_count',
            render: text => <a>{text}</a>,
        },
        {
            dataIndex: 't',
            tit: 't',
            render: (text) => <a>{text}</a>,
        },
        {
            dataIndex: 'title',
            tit: 'title',
            render: (text,obj)=>
            <Link to={'/Details/'+obj.id}>{text}</Link>
        },
        {
            dataIndex: 'last_reply_at',
            tit: 'last_reply_at',
            render: text => <a>{changeTime(text)}</a>,
        },
    ]
    function callback(key) {
        console.log(key);
    }
    return (
        <div id="div">
            <img src='./head.png' id="img" />
            <Tabs defaultActiveKey="1" onChange={callback} id="tab">
                <TabPane tab="全部" key="1">
                    <Table columns={columns} dataSource={data} />
                </TabPane>
                <TabPane tab="问答" key="2">
                    <Table columns={columns} dataSource={data.filter(item => item.t == `问答`)} />
                </TabPane>
                <TabPane tab="分享" key="3">
                    <Table columns={columns} dataSource={data.filter(item => item.t == `分享`)} />
                </TabPane>
            </Tabs>
            <Detail/>
        </div>
    )
}